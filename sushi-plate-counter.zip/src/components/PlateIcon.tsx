import type { PlateTier } from '../data/plates';

interface PlateIconProps {
  tier: PlateTier;
  size?: number;
  className?: string;
}

export function PlateIcon({ tier, size = 22, className = '' }: PlateIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 28 28"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className={className}
    >
      <circle
        cx="14"
        cy="14"
        r="12"
        fill={tier.fillColor}
        stroke={tier.rimColor}
        strokeWidth="1.5"
      />
      <circle
        cx="14"
        cy="14"
        r="7.2"
        stroke={tier.innerRingColor}
        strokeWidth="1.1"
        strokeOpacity={tier.id === 'black' ? 0.9 : 0.75}
      />
    </svg>
  );
}
