import { useState } from 'react';
import { BellRing, CheckCircle2, QrCode, RotateCcw, X } from 'lucide-react';
import { calculateBill, formatBaht, type PlateCounts } from '../data/plates';
import { PromptPayQR } from './PromptPayQR';

interface CheckoutSheetProps {
  isOpen: boolean;
  onClose: () => void;
  counts: PlateCounts;
  includeServiceCharge: boolean;
  onResetOrder: () => void;
}

export function CheckoutSheet({
  isOpen,
  onClose,
  counts,
  includeServiceCharge,
  onResetOrder,
}: CheckoutSheetProps) {
  const [mode, setMode] = useState<'qr' | 'staff'>('qr');
  const [done, setDone] = useState(false);

  if (!isOpen) return null;

  const { subtotal, serviceCharge, total, totalPlates } = calculateBill(
    counts,
    includeServiceCharge
  );

  const handleClose = () => {
    setDone(false);
    onClose();
  };

  const handleNewBill = () => {
    setDone(false);
    onResetOrder();
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 backdrop-blur-sm sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="checkout-title"
    >
      <div className="w-full max-w-[390px] rounded-t-3xl border border-zinc-800 bg-[#0E0E11] p-5 text-zinc-50 shadow-2xl sm:rounded-3xl">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 id="checkout-title" className="text-base font-bold text-white">
              เรียกเก็บเงิน
            </h2>
            <p className="text-xs text-zinc-400 font-mono-num">
              {totalPlates} จาน · {formatBaht(subtotal)}฿
              {includeServiceCharge ? ` + 10% (${formatBaht(serviceCharge)}฿)` : ''}
            </p>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="ปิด"
            className="flex h-10 w-10 items-center justify-center rounded-xl text-zinc-400 hover:bg-zinc-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {done ? (
          <div className="py-4 text-center space-y-4">
            <CheckCircle2 className="mx-auto h-11 w-11 text-emerald-400" />
            <div>
              <p className="text-base font-bold text-white">
                {mode === 'qr' ? 'ชำระเงินเรียบร้อย' : 'เรียกพนักงานเก็บเงินแล้ว'}
              </p>
              <p className="mt-1 font-mono-num text-sm text-zinc-400">
                ยอดสุทธิ {formatBaht(total)} บาท
              </p>
            </div>
            <button
              type="button"
              onClick={handleNewBill}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-white text-sm font-bold text-zinc-950 active:scale-[0.98]"
            >
              <RotateCcw className="h-4 w-4" />
              เริ่มคิดบิลใหม่
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-1.5 rounded-xl bg-zinc-900 p-1">
              <button
                type="button"
                onClick={() => setMode('qr')}
                className={`flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  mode === 'qr' ? 'bg-zinc-800 text-white' : 'text-zinc-400'
                }`}
              >
                <QrCode className="h-4 w-4" />
                สแกน QR
              </button>
              <button
                type="button"
                onClick={() => setMode('staff')}
                className={`flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  mode === 'staff' ? 'bg-zinc-800 text-white' : 'text-zinc-400'
                }`}
              >
                <BellRing className="h-4 w-4" />
                เรียกพนักงาน
              </button>
            </div>

            {mode === 'qr' ? (
              <PromptPayQR amount={total} tableNumber="none" />
            ) : (
              <div className="rounded-2xl border border-zinc-800 bg-zinc-900/50 py-6 text-center">
                <p className="text-xs text-zinc-400">ยอดชำระสุทธิ</p>
                <p className="mt-1 font-mono-num text-4xl font-bold text-white">
                  {formatBaht(total)} ฿
                </p>
              </div>
            )}

            <button
              type="button"
              onClick={() => setDone(true)}
              className="flex min-h-[48px] w-full items-center justify-center rounded-xl bg-white text-sm font-bold text-zinc-950 transition-transform active:scale-[0.98]"
            >
              {mode === 'qr' ? 'ยืนยันชำระเงิน' : 'เรียกพนักงานเก็บเงิน'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
