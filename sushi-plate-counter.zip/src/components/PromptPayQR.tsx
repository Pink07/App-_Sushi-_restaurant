import { useMemo } from 'react';
import { formatBaht } from '../data/plates';

interface PromptPayQRProps {
  amount: number;
  tableNumber: string;
}

export function PromptPayQR({ amount, tableNumber }: PromptPayQRProps) {
  const size = 21;

  const matrix = useMemo(() => {
    const grid: boolean[][] = Array.from({ length: size }, () =>
      Array.from({ length: size }, () => false)
    );

    const drawFinder = (startR: number, startC: number) => {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          const isBorder = r === 0 || r === 6 || c === 0 || c === 6;
          const isCenter = r >= 2 && r <= 4 && c >= 2 && c <= 4;
          grid[startR + r][startC + c] = isBorder || isCenter;
        }
      }
    };

    drawFinder(0, 0);
    drawFinder(0, size - 7);
    drawFinder(size - 7, 0);

    // Deterministic pseudo-random fill seeded from amount & tableNumber
    let seed = Math.round(amount * 100) + 1337;
    for (let i = 0; i < tableNumber.length; i++) {
      seed = (seed * 31 + tableNumber.charCodeAt(i)) >>> 0;
    }

    const nextBit = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return (seed & 0x10000) !== 0;
    };

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const inTopLeft = r < 8 && c < 8;
        const inTopRight = r < 8 && c >= size - 8;
        const inBottomLeft = r >= size - 8 && c < 8;
        if (inTopLeft || inTopRight || inBottomLeft) continue;

        if (r === 6 || c === 6) {
          grid[r][c] = (r + c) % 2 === 0;
        } else {
          grid[r][c] = nextBit();
        }
      }
    }

    return grid;
  }, [amount, tableNumber]);

  return (
    <div className="mx-auto w-full max-w-[260px] rounded-2xl bg-white p-4 text-zinc-950 shadow-sm">
      <div className="mb-3 flex items-center justify-between border-b border-zinc-200 pb-2">
        <span className="text-xs font-bold tracking-tight text-sky-900">
          Thai QR Payment
        </span>
        <span className="text-[11px] font-medium text-zinc-500">
          {tableNumber === 'none' ? 'PromptPay' : `โต๊ะ ${tableNumber}`}
        </span>
      </div>

      <div className="flex items-center justify-center rounded-xl bg-white p-2">
        <svg
          viewBox={`0 0 ${size} ${size}`}
          className="h-40 w-40"
          role="img"
          aria-label={`PromptPay QR สำหรับยอด ${formatBaht(amount)} บาท`}
        >
          <rect width={size} height={size} fill="#ffffff" />
          {matrix.map((row, r) =>
            row.map((cell, c) =>
              cell ? (
                <rect
                  key={`${r}-${c}`}
                  x={c}
                  y={r}
                  width={0.95}
                  height={0.95}
                  fill="#09090b"
                  rx={0.12}
                />
              ) : null
            )
          )}
        </svg>
      </div>

      <div className="mt-3 border-t border-zinc-200 pt-2.5 text-center">
        <p className="text-[11px] text-zinc-500">ยอดชำระสุทธิ</p>
        <p className="font-mono-num text-xl font-bold text-zinc-950">
          ฿{formatBaht(amount)}
        </p>
      </div>
    </div>
  );
}
