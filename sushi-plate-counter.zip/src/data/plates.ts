export type PlateId = 'white' | 'red' | 'silver' | 'gold' | 'black';

export interface PlateTier {
  id: PlateId;
  price: number;
  priceLabel: string;
  colorNameTh: string;
  tierNameTh: string;
  examplesTh: string;
  rimColor: string;
  fillColor: string;
  innerRingColor: string;
  accentBarClass: string;
}

export const PLATE_TIERS: PlateTier[] = [
  {
    id: 'white',
    price: 30,
    priceLabel: '30฿',
    colorNameTh: 'จานสีขาว',
    tierNameTh: 'เมนูพื้นฐาน',
    examplesTh: 'เมนูมาตรฐานเริ่มต้น',
    rimColor: '#CBD5E1',
    fillColor: '#F8FAFC',
    innerRingColor: '#E2E8F0',
    accentBarClass: 'bg-slate-100',
  },
  {
    id: 'red',
    price: 40,
    priceLabel: '40฿',
    colorNameTh: 'จานสีแดง',
    tierNameTh: 'เมนูทั่วไป',
    examplesTh: 'แซลมอน, ไข่หวาน',
    rimColor: '#991B1B',
    fillColor: '#DC2626',
    innerRingColor: '#F87171',
    accentBarClass: 'bg-red-600',
  },
  {
    id: 'silver',
    price: 60,
    priceLabel: '60฿',
    colorNameTh: 'จานสีเงิน',
    tierNameTh: 'เมนูพิเศษ',
    examplesTh: 'มากุโระ, หมึกโฮตารุ',
    rimColor: '#64748B',
    fillColor: '#CBD5E1',
    innerRingColor: '#F1F5F9',
    accentBarClass: 'bg-slate-400',
  },
  {
    id: 'gold',
    price: 80,
    priceLabel: '80฿',
    colorNameTh: 'จานสีทอง',
    tierNameTh: 'เมนูพรีเมียม / ปรุงพิเศษ',
    examplesTh: 'เมนูพรีเมียมและซอสปรุงพิเศษ',
    rimColor: '#A16207',
    fillColor: '#EAB308',
    innerRingColor: '#FEF08A',
    accentBarClass: 'bg-amber-500',
  },
  {
    id: 'black',
    price: 120,
    priceLabel: '120฿',
    colorNameTh: 'จานสีดำ',
    tierNameTh: 'เมนูพรีเมียมสูงสุด',
    examplesTh: 'โฮตาเตะ, เนื้อวากิว',
    rimColor: '#71717A',
    fillColor: '#18181B',
    innerRingColor: '#3F3F46',
    accentBarClass: 'bg-zinc-600',
  },
];

export type PlateCounts = Record<PlateId, number>;

export const INITIAL_COUNTS: PlateCounts = {
  white: 0,
  red: 0,
  silver: 0,
  gold: 0,
  black: 0,
};

export function calculateBill(counts: PlateCounts, includeServiceCharge: boolean) {
  const subtotal = PLATE_TIERS.reduce(
    (sum, tier) => sum + tier.price * (counts[tier.id] || 0),
    0
  );
  const totalPlates = PLATE_TIERS.reduce(
    (sum, tier) => sum + (counts[tier.id] || 0),
    0
  );
  const serviceCharge = includeServiceCharge ? Math.round(subtotal * 0.1 * 100) / 100 : 0;
  const total = Math.round((subtotal + serviceCharge) * 100) / 100;

  return {
    subtotal,
    serviceCharge,
    total,
    totalPlates,
  };
}

export function formatBaht(amount: number): string {
  if (Number.isInteger(amount)) {
    return amount.toLocaleString('th-TH');
  }
  return amount.toLocaleString('th-TH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}
